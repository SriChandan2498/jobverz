import React, { Component } from 'react'
import './App.css';
import Graph from './Graph';
// import SelectBar from './SelectBar'
// import amazonData from './skillsData/AmazonData'

class App extends Component 
{
    render() 
    {
        return(<Graph/>);
    }
}
export default App;


